<?php

class Usuario_modelo extends CI_Model {
	
	public $email;
    public $nombre;
	public $apellido;
	
	//--------------------------------GESTIÓN DE USUARIOS-------------------------------------------
    public function get_usuario_by_email($email){
		$this->db->select('email','nombre','apellido');
		$this->db->where('email', $email);
        $query = $this->db->get('usuarios');
        return $query->result();
	}

	public function nuevo_usuario 			($email,$nombre,$apellido,$password,$genero,$numero,$nacimiento,$pagina,$pais
							,$provincia,$ciudad,$calle,$altura,$coordenadas){
		$hash = password_hash($password, PASSWORD_DEFAULT, [15]);
		$data = array(
			'email' => $email,
			'nombre' => $nombre,
			'apellido' => $apellido,
			'password' => $hash,
			'genero' => $genero,
			'telefono' => $numero,
			'nacimiento' => $nacimiento,
			'pagina_web' => $pagina,
			'pais' => $pais,
			'provincia' => $provincia,
			'ciudad' => $ciudad,
			'calle' => $calle,
			'altura' => $altura);
		
		$result = $this->db->insert('usuarios', $data);
		return $result;
	}

	public function inicio_sesion($email){
		$this->db->select('password, nombre, apellido');
		$this->db->where('email', $email);
		$query = $this->db->get('usuarios');
		return $query;
	}
	
	public function actualizar_datos($emailBusquedaUsuario, $email, $password, $nombre, $apellido){
		$hash = password_hash($password, PASSWORD_DEFAULT, [15]);
		$data = array(
			'email' => $email,
			'nombre' => $nombre,
			'apellido' => $apellido,
			'password' => $hash);
			
		$this->db->where('email', $emailBusquedaUsuario);
		return $this->db->update('usuarios', $data);
	}
	
	//--------------------------------GESTIÓN DE VIDEOS-------------------------------------------
	public function insertVideos($videos){
		foreach($videos as $fila=>$elementos){           
			$data = array (
				"email" => $elementos["email"],
				"titulo_busqueda" => $elementos["titulo_busqueda"],
				"id_video" => $elementos["id_video"]);
			$this->db->insert('videos', $data);
		}
	}
	
    public function deleteAllVideos($email){
        $this->db->where('email', $email);
        $this->db->delete('videos');
    }

    public function getVideos($email){
		$query= "select * from videos where email = '$email' ";
		$resultado=$this->db->query($query);
		return $resultado->result();
    }
	
    public function updateMailVideos($emailAntiguo, $emailNuevo){
		$this->db->set('email', $emailNuevo);
		$this->db->where('email', $emailAntiguo);
		$this->db->update('videos');
    }
}