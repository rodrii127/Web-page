<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {

	public function paginaInicio(){
		if($this->session->has_userdata('logeado')){
			$this->load->view('home-page.php');
		}else{
			$this->load->view('login-usuarios.php');
		}
	}
	
	public function registrar(){
		$this->load->view('registro-usuarios.php');
	}
	
	public function login(){
		$this->load->view('login-usuarios.php');
	}
	
	public function nuevoUsuario(){
		//obtiene las variables que se enviar por el formulario de registro via metodo POST
		$email = $this->input->post('email');
		$password = $this->input->post('password');
        $nombre = $this->input->post('nombre');
        $apellido = $this->input->post('apellido');
		$genero = $this->input->post('genero');
		$numero = $this->input->post('numero');
		$nacimiento = $this->input->post('nacimiento');
		$pagina = $this->input->post('pagina');
		$pais = $this->input->post('pais');
		$provincia = $this->input->post('provincia');
		$ciudad = $this->input->post('ciudad');
		$calle = $this->input->post('calle');
		$altura = $this->input->post('altura');
		$coordenadas = $this->input->post('coordenadas');
            
        //carga el modelo de usuarios y ejecuta el metodo para insertar un usuario en la DB
        $this->load->model('usuario_modelo','usuario');
            
		//valida el email que no exista antes de insertar, esto a nivel de servidor
        $arr_usuario=$this->usuario->get_usuario_by_email($email);
        if(count($arr_usuario)>0){
                
        	$data = array(
            'warning' => true,                
            'message' => 'Ya existe un usuario registrado con el correo ingresado'
            );
                
            $this->load->view('registro-usuarios',$data);
		}else{
        	$resul=$this->usuario->nuevo_usuario($email,$nombre,$apellido,$password,$genero,$numero,$nacimiento,$pagina,$pais
							,$provincia,$ciudad,$calle,$altura,$coordenadas);
            //si el resultado del insert retorno true, quiere decir que se agrego correctamente el usuario
            if($resul==true){
				$data = array(
                'success' => true,                
                'message' => 'Usuario registrado correctamente'
                );
				
				echo'<script type="text/javascript">alert("¡Se registró al usuario!");</script>';
				
                $this->load->view('login-usuarios',$data);

			}else{        
				$data = array(
                'error' => true,                
                'message' => 'Error al intentar registrar el usuario'
                );
                    
                $this->load->view('registro-usuarios',$data);
			}                               
		}
	}
	
	
	public function modificar_usuario(){
        $emailBusquedaUsuario = $this->session->userdata('email');
        $email = $this->input->post('emailInput');
        
        $password = $this->input->post('passwordInput');
        $nombre = $this->input->post('nombreInput');
        $apellido = $this->input->post('apellidoInput');
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        $this->load->model('usuario_modelo','usuario');
		
        $result =$this->usuario->actualizar_datos($emailBusquedaUsuario, $email, $password, $nombre, $apellido);
        
		if($result==true){
			$result =$this->usuario->updateMailVideos($emailBusquedaUsuario, $email);
            echo "exito";
        }else{
            echo "Ocurrio un error";
        }   
    }
	
	public function validar_email(){
            //obtiene las variables que se enviar por el formulario de registro via metodo POST
            $email = $this->input->post('email');
            
            //carga el modelo de usuarios y ejecuta el metodo para insertar un usuario en la DB
            $this->load->model('usuario_modelo','usuario');
            
            $arr_usuario=$this->usuario->get_usuario_by_email($email);
            if(count($arr_usuario)>0){
                
                $data = array('warning' => true);
               
            }else{
                $data = array('success' => true);                
            }
            echo json_encode($data); 
        }
	
	public function validar_email_modificacion(){
        $email = $this->input->post('emailInput');
		$emailDeSesion = $this->session->userdata("email");
		$this->load->model('usuario_modelo','usuario');
		$arr_usuario=$this->usuario->get_usuario_by_email($email);
		if(count($arr_usuario)>0 && !($email == $emailDeSesion) ){
			echo "invalido";         
		}else{
			echo "valido";                
		}
    }
	
	public function inicioSesion(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');
            
        //carga el modelo de usuarios y ejecuta el metodo para insertar un usuario en la DB
        $this->load->model('usuario_modelo','usuario');
            
		$arr_usuario=$this->usuario->inicio_sesion($email);
        if(count($arr_usuario->result())>0){
            foreach ($arr_usuario->result() as $row){
				$hash = $row->password;
				$password = $this->input->post('password');
				if(password_verify($password, $hash)){
					echo'<script type="text/javascript">alert("¡Login exitoso!");</script>';
					$nombre = $row ->nombre;
					$apellido = $row ->apellido;
					$this->iniciar_sesion_servidor($email, $nombre, $apellido);
					$this->load->view('home-page.php');
				}else{
					echo'<script type="text/javascript">alert("Password inválido");</script>';
					$this->load->view('login-usuarios.php');
				}
			}
		}else{
			echo'<script type="text/javascript">alert("Ingrese un mail válido por favor");</script>';
			$this->load->view('login-usuarios.php');
		}
	}
	
	public function iniciar_sesion_servidor($email, $nombre, $apellido){
		//Creo un array con la informacion que voy a guardar en mi sesion, de verlo conveniente puedo 
		//guardar otros datos.
		$espacio = " ";
		$nombre_completo = $nombre.$espacio.$apellido;
		$array_sesion = array(
			'nombre' => $nombre_completo,
			'apellido' => $apellido,
			'email' => $email,
			'logeado' => TRUE
		);
		//guarda los datos en la sesion de codeigniter
		$this->session->set_userdata($array_sesion);
	}

	public function cerrar_sesion_servidor(){
		session_destroy();
		$this->login();
	}
	
	
	public function chargeVideos(){
		$email = $this->session->userdata("email");      
		$this->load->model('usuario_modelo','usuario');
		$videos=$this->usuario->getVideos($email);
        $devolver = json_encode($videos);
        echo $devolver;
    }
	
	public function insertVideos(){
		$videos = json_decode(json_encode($this->input->post('arreglo1')), True);
		$email=$this->session->userdata("email");
		$this->load->model('usuario_modelo','usuario');
		$this->usuario->deleteAllVideos($email);
		$this->usuario->insertVideos($videos);
	 }
}