<!DOCTYPE html>
<html lang="en">
<head>
	
	<meta charset="utf-8">
	<title>Home-Page - Taller de Aplicaciones Web</title>
	
	<!--Archivos .js: ajax, jquery, jqueryUI, apiYouTube y archivo propio-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
	<script src="https://apis.google.com/js/api.js"></script>
	<script src="http://localhost/codeigniter/js/home-page.js"></script>
	<!--Archivos .css: Bootstrap, jquery y el archivo propio-->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.jqueryui.min.css" type="text/css"/>
	<link rel="stylesheet" href="http://localhost/codeigniter/css/home-page.css">
</head>

	<body>
		<header style="display: flex;">
			<div style="margin-left: 40%; margin-top: 10px;">
				<h1>VideoTrends</h1>
            </div>
    
            <div style="margin-top: 20px; margin-left: 15%; display: flex;"> 
                <div>
                    <select id="select_menu" style="text-align:center;">
                        <option selected="" disabled="" id="emailIUsuario"> <?php echo $this->session->userdata("nombre") ?> </option>
                        <option value="modificar">Modificar perfil</option>
                    </select>
                </div> 
                <div>
					<!--ver si puedo ponerlo dentro del select menu-->
                    <form action="http://localhost/codeigniter/usuarios/cerrar_sesion_servidor" method="post">
						<button title="Cerrar sesion" class="btn btn-danger" style="font-size: 13px;"><b>Salir</b></button>
                    </form>
                </div>
            </div>
		</header>
		
		<div id="menu_dialogo" title="Modificación de cuenta">
			<form method="POST">
				<div class="form-group">
					<label for="emailInput">Ingrese el nuevo mail</label>
					<input type="email" class="form-control" id="emailInput" aria-describedby="emailHelp">
					<small id="emailHelp" class="form-text text-muted">El email no tiene que haberse utilizado para crear otra cuenta.</small>
					<span id="span_email"></span>
				</div>
				<div class="form-group">
					<label for="passwordInput">Ingrese la contraseña</label>
					<input type="password" class="form-control" id="passwordInput">
				</div>
				<div class="form-group">
					<label for="passwordInput2">Repita la contraseña</label>
					<input type="password" class="form-control" id="passwordInput2">
					<small id="emailHelp" class="form-text text-muted">Las contraseñas deben coincidir.</small>
					<span id="span_password"></span>
				</div>
				<div class="form-group">
					<label for="nombreInput">Ingrese el nombre del usuario</label>
					<input type="text" class="form-control" id="nombreInput">
				</div>
				<div class="form-group">
					<label for="apellidoInput">Ingrese el apellido del usuario</label>
					<input type="text" class="form-control" id="apellidoInput">
				</div>
				<div style="text-align: center;">
					<button id="boton_modificar_usuario" class="btn btn-success">Guardar</button>
				</div>
            </form>
		</div>
        
        <div style="display: flex; margin-top: 3%;">
            <div style="width: 90%;">
                <form style="margin-left: 20px; margin-right: 10px;">
                    <div class="form-group">
                        <label for="formGroupExampleInput">Título</label>
                        <input type="text" class="form-control" id="titulo-video">
                      </div>
                      <div class="form-group">
                        <label for="formGroupExampleInput2">Términos de mi busqueda</label>
						  <input type="text"  class="form-control" id="termino_busqueda">
                      </div>
                </form>
            </div>
			
			<img src="http://localhost/codeigniter/img/play.png" alt="botón buscar" title="Presione para buscar"
				 height="5%" width="5%" onClick="search()" style="margin-top: 4%;">
        </div>
		
		<div id="acordion">
          <h1>Resultados de la búsqueda</h1>
          <div id="resultado"><ul class="resultados_grilla" id="sortable"></ul></div>    
        </div>
	</body>
</html>