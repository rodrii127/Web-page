<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<h1>ponete feliz porque iniciaste sesion</h1>
	<form action="http://localhost/codeigniter/Usuarios/cerrar_sesion_servidor" method="post">
		<button title="Cerrar la sesión." id="botonCerrarSesion">Cerrar Sesion</button>
	</form>
</body>
</html>