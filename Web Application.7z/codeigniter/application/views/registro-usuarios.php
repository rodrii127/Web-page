<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registro de Usuarios</title>
	<link rel="stylesheet" href="http://localhost/codeigniter/css/style-registro-usuarios.css">
	<link rel="stylesheet" href="http://localhost/codeigniter/css/jquery-ui.css">
	<script src="http://localhost/codeigniter/js/jquery-3.5.1.min.js"></script>
	<script src="http://localhost/codeigniter/js/jquery-ui.js"></script>
	<script src="http://localhost/codeigniter/js/usuarios.js"></script>
</head>

<body>
	<header class="header">
		<h1>Registro de Usuarios</h1>
	</header>
	
	<nav class="nav">
		<p><a href="http://localhost/codeigniter/Usuarios/login">Iniciar Sesion</a></p>
		<p><a href="">Olvide mi Contraseña</a></p>
		<p><a href="">Acerca de Nosotros</a></p>
	</nav>
	
	<section class="section">
		<aside class="aside">
			<div class="aside-div-1">
				<p><img src="http://localhost/codeigniter/img/argentina.png" alt="Argentina, un pais con buena gente ?)" width="30%"></p>
			</div>
			<div class="aside-div-2">
				<p>Al hacer click en "Crear mi Cuenta", acepta las Condiciones y confirmas que leíste nuestra Política de datos, incluído el uso de cookies.</p>
			</div>
		</aside>
		
		<form action="http://localhost/codeigniter/Usuarios/nuevoUsuario" method="post" class="registro-usuarios">
			<h2>Datos de Inicio de Sesión</h2>
			<label for="email">E-mail</label>
			<input type="email" name="email" id="email" title="Ingrese el e-mail." onblur="validarEmailAjax()" required>
			<span id="span_email"></span>
			<br> <br>
			<label for="password">Contraseña</label>
			<input type="password" name="password" id="password" class="campo-texto" title="Ingrese la contraseña." required>
			<br> <br>
			<label for="password2">Repetir Contraseña</label>
			<input type="password" name="password2" id="password2" class="campo-texto" title="Ingrese la contraseña nuevamente." onblur="validarPassword()" required>
			<span id="span_pass"></span>

			<h2>Datos Personales</h2>
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre" maxlength="60" title="Ingrese su nombre.">
			<br><br>
			<label for="apellido">Apellido</label>
			<input type="text" name="apellido" maxlength="60" title="Ingrese su apellido.">
			<br><br>
			<p style="margin-left: 30px;">Género</p>
			<input type="radio" id="masculino" name="genero" value="masculino" style="margin-left: 30px; width: auto;" title="Ingrese su género.">
			<label for="masculino" style="margin-left: 0px;">Masculino</label><br>
			<input type="radio" id="femenino" name="genero" value="femenino" style="margin-left: 30px; width: auto;" title="Ingrese su género.">
			<label for="femenino" style="margin-left: 0px;">Femenino</label><br>
			<br><br>
			<label for="numero">Número de Teléfono</label>
			<input type="number" name="numero" title="Ingrese su número telefónico.">
			<br><br>
			<label for="nacimiento">Fecha de Nacimiento</label>
			<input id="datepicker" type="text" name="nacimiento" title="Ingrese su fecha de nacimiento.">
			<br><br>
			<label for="pagina">Página Web</label>
			<input type="url" name="pagina" title="Ingrese su página web.">
			
			<h2>Datos de Localización</h2>
			<label for="pais">País</label>
			<select name="pais" id="nacionalidad" title="Ingrese su nacionalidad.">
				<option value="Argentina" selected>Argentina</option> 
				<option value="Paraguay">Paraguay</option>
				<option value="Uruguay">Uruguay</option>
				<option value="Chile">Chile</option>
				<option value="Bolivia">Bolivia</option>
				<option value="Brasil">Brasil</option>
				<option value="Colombia">Colombia</option>
				<option value="Venezuela">Venezuela</option>
				<option value="Peru">Perú</option>
				<option value="Estados Unidos">Estados Unidos</option>
				<option value="Canada">Canadá</option>
				<option value="España">España</option>
			</select>
			<br><br>
			<label for="provincia">Provincia / Estado</label>
			<select name="provincia" id="provincia" title="Ingrese su provincia.">
				<option value="Buenos Aires">Bs. As.</option>
				<option value="Catamarca">Catamarca</option>
				<option value="Chaco">Chaco</option>
				<option value="Chubut">Chubut</option>
				<option value="Cordoba">Cordoba</option>
				<option value="Corrientes">Corrientes</option>
				<option value="Entre Rios">Entre Rios</option>
				<option value="Formosa">Formosa</option>
				<option value="Jujuy">Jujuy</option>
				<option value="La Pampa">La Pampa</option>
				<option value="La Rioja">La Rioja</option>
				<option value="Mendoza">Mendoza</option>
				<option value="Misiones" selected>Misiones</option>
				<option value="Neuquen">Neuquen</option>
				<option value="Rio Negro">Rio Negro</option>
				<option value="Salta">Salta</option>
				<option value="San Juan">San Juan</option>
				<option value="San Luis">San Luis</option>
				<option value="Santa Cruz">Santa Cruz</option>
				<option value="Santa Fe">Santa Fe</option>
				<option value="Sgo. del Estero">Sgo. del Estero</option>
				<option value="Tierra del Fuego">Tierra del Fuego</option>
				<option value="Tucuman">Tucuman</option>
			</select>
			<br><br>
			<label for="ciudad">Ciudad</label>
			<select name="ciudad" id="ciudad" title="Ingrese su ciudad.">
				<option value="Apostoles">Apóstoles</option>
				<option value="Posadas" selected>Posadas</option>
				<option value="Obera">Oberá</option>
				<option value="Iguazu">Iguazú</option>
			</select>
			<br><br>
			<label for="calle">Calle</label>
			<input type="text" name="calle" title="Ingrese su calle.">
			<br><br>
			<label for="altura">Altura</label>
			<input type="number" name="altura" title="Ingrese la altura de la calle.">
			<br><br>
			<label for="coordenadas">Coordenadas</label>
			<input type="number" name="coordenadas" class="coordenadas-input" title="Ingrese su coordenada.">
			<input type="number" name="coordenadas" class="coordenadas-input" title="Ingrese su coordenada.">
			
			<br><br>
			<button title="Enviar formulario." id="botonCrearUsuario">Crear Cuenta</button>
		</form>
	</section>
	
	<footer class="footer">
		<p><a href="https://www.youtube.com/" target="_blank">YouTube</a></p>
		<p><a href="https://www.ugd.edu.ar/" target="_blank">U.G.D.</a></p>
		<p><a href="https://campusvirtual.ugd.edu.ar/moodle/login/index.php" target="_blank">Campus Virtual</a></p>
	</footer>
</body>
</html>
