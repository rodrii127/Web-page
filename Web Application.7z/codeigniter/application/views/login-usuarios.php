<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Inicio de Sesión</title>
	<link rel="stylesheet" href="http://localhost/codeigniter/css/style.css">
	<script src="http://localhost/codeigniter/js/jquery-3.5.1.min.js"></script>
	<script src="http://localhost/codeigniter/js/jquery-ui.js"></script>
	<script src="http://localhost/codeigniter/js/usuarios.js"></script>
</head>

<body>
	<header class="header">
		<a href="index.html"><img src="http://localhost/codeigniter/img/youtube.png" alt="iconoPag" width="50px" height="50px"></a>
		<h1><a href="index.html">VideoTrend</a></h1>
		<h2>Mira tus videos de YouTube como quieras</h2>
	</header>
	
	<nav class="nav">
		<p><a href="http://localhost/codeigniter/Usuarios/registrar" target="_self">Crear una Cuenta</a></p>
		<p><a href="" target="_blank">Olvide mi Contraseña</a></p>
		<p><a href="" target="_blank">Acerca de Nosotros</a></p>
	</nav>
	
	<section class="section">
		<div id="imagen-banner">
			<img src="http://localhost/codeigniter/img/argentina.png" alt="Argentina" height="390px" width="250px">
		</div>
		<div id="div-formulario">
			<form action="http://localhost/codeigniter/Usuarios/inicioSesion" method="post" class="formulario">
				<input type="email" name="email" id="email" onBlur="validarEmailInicioSesion()">
				<p align="center">E-mail</p>
				<input type="password" name="password" id="password">
				<p align="center">Contraseña</p>
				<input type="submit" value="Iniciar Sesión" id="iniciarSesion">
			</form>
			<hr>
			<form action="http://localhost/codeigniter/Usuarios/registrar" class="formulario">
         		<input type="submit" value="Crear Cuenta">
      		</form>
		</div>
	</section>
	
	<footer class="footer">
		<p><a href="https://www.youtube.com/" target="_blank">YouTube</a></p>
		<p><a href="https://www.ugd.edu.ar/" target="_blank">U.G.D.</a></p>
		<p><a href="https://campusvirtual.ugd.edu.ar/moodle/login/index.php" target="_blank">Campus Virtual</a></p>
	</footer>
</body>
</html>
