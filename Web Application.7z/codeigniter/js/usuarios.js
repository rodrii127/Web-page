$(function () {
	$( document ).tooltip();
	$("#datepicker").datepicker({
		dateFormat: 'yy-mm-dd'
	});
});
  

function validarEmailAjax(){
	$.ajax({
        method: "POST",
        url: "/codeigniter/Usuarios/validar_email",
        data: {email: $('#email').val()}
    }).done(function( msg ) {
        
        var data=JSON.parse(msg);
        
        if(data.warning){
			$('#span_email').text("E-mail no válido");
			$('#span_email').css({ 'color': 'red'});
            $('#botonCrearUsuario').prop('disabled', true);
        }
        
        if(data.success){
			$('#span_email').text("E-mail válido");
			$('#span_email').css({ 'color': 'green'});
            $('#botonCrearUsuario').prop('disabled', false);
        }   
	});       
}

function validarPassword(){
	$.ajax({

	}).done(function() {
		var pass = $('#password').val();
		var pass2 = $('#password2').val();
			
		if(!pass == pass2){
			$('#span_pass').text("No coinciden");
			$('#span_pass').css({ 'color': 'red'});
            $('#botonCrearUsuario').prop('disabled', true); 
		}else{
			$('#span_pass').text("Coinciden");
			$('#span_pass').css({ 'color': 'green'});
            $('#botonCrearUsuario').prop('disabled', false);
		}
	});
}


function validarEmailInicioSesion(){
	$.ajax({
        method: "POST",
        url: "/codeigniter/Usuarios/validar_email",
        data: {email: $('#email').val()}
    }).done(function( msg ) {
        
        var data=JSON.parse(msg);
        
        if(data.warning){
			alert("E-mail válido");
            $('#iniciarSesion').prop('disabled', false);
        }
        if(data.success){
			alert("E-mail inválido, verifique los datos");
            $('#iniciarSesion').prop('disabled', true);
        }   
	});       
}