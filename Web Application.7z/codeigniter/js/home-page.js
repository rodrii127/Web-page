//cuando se carga la pagina completamente
//inicializa el cliente js de la API de youtube
$( document ).ready(function() {
	
	chargeUserVideos();
	
	$("#sortable").sortable({
        connectWith: "ul",
        remove: function( event, ui ) {
			insertarNuevoVideo();
		}
	});
 
    
	$( "#acordion" ).accordion();
    $( "#acordion1" ).accordion();
	
	
    $( "#select_menu" ).selectmenu({
		width: 300,
		icons: { button: "ui-icon-power" },
		classes: {
			"ui-selectmenu-menu": "highlight"
		},
		select: function(event, ui){
			if(ui.item.value== "modificar"){	
				$("#menu_dialogo").dialog("open");
			}		
		}
	});
    
	$("#boton_modificar_usuario").prop('disabled', true);
    $("#menu_dialogo").dialog({
		autoOpen: false,
		width: 500,
		height: 600,
		draggable: false,
		modal: true
	});
    
	$("#emailInput").blur(function (e) { 
		e.preventDefault(); 
		$.ajax({
			type: "POST",
			url: "http://localhost/codeigniter/Usuarios/validar_email_modificacion",
			data: {emailInput: $("#emailInput").val()},                   
			success: function (msg) {                   
				if(msg=="valido"){
					$('#span_email').text("E-mail válido");
					$('#span_email').css({ 'color': 'green'});
					$('#boton_modificar_usuario').prop('disabled', false);
				}
				if(msg == "invalido"){
					$('#span_email').text("E-mail no válido");
					$('#span_email').css({ 'color': 'red'});
					$('#boton_modificar_usuario').prop('disabled', true);
				}
			}
		});  
	});

	$("#boton_modificar_usuario").click(function(e){
		var flagCamposVacios = false;
		
		//Hago la revisión de que los campos no estén vacíos...
		if(!$("#emailInput").val()=="" && $("#passwordInput").val()!="" && $("#passwordInput2").val()!="" && $("#nombre").val()!="" && $("#apellido").val()!=""){
			flagCamposVacios = true;
		}
		
		if(flagCamposVacios){
			//Si las contraseñas coinciden paso a modificar el usuario en la BD
			if($("#passwordInput").val()==$("#passwordInput2").val()){
				$.ajax({
					type: "POST",
					url: "http://localhost/codeigniter/Usuarios/modificar_usuario",
					data: {emailInput: $("#emailInput").val(), passwordInput: $("#passwordInput").val(), nombreInput: $("#nombreInput").val(), apellidoInput: $("#apellidoInput").val() },           
					success: function (msg) {  
						if(msg=="exito"){
							alert("Modificacion exitosa");
							$("#menu_dialogo").dialog( "close" );
							window.location.replace("http://localhost/codeigniter/usuarios/login");
						}else{
							alert("No se pudo modificar al usario");
						}                                                           
					}
				});
			}else{
				alert("Las contraseñas deben coincidir");
				$('#span_password').text("Las contraseñas no coinciden");
				$('#span_password').css({ 'color': 'red'});
			}
		}               
	});
});


var id_video ="";
var matriz_principal_videos = [];
var matriz_secundaria_videos = [];
var titulo_video = "";
var titulo_video_anterior = "";
var flag_segunda_busqueda = false;


function start() {
	// Initializes the client with the API key and the Translate API.
	gapi.client.init({
		'apiKey': 'AIzaSyD2Pa12HvLxnYbRy4Lt3pokcRaEKipdZLc',
		'discoveryDocs': ['https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest'],
	}).then(function() {
	
		// Executes an API request, and returns a Promise.
		// The method name `language.translations.list` comes from the API discovery.
		return gapi.client.youtube.search.list({
			q: 'cats',
			part: 'snippet',
		});
	}).then(function(response) {
	}, function(reason) {
		console.log('Error: ' + reason.result.error.message);
	});
};

// Loads the JavaScript client library and invokes `start` afterwards.
gapi.load('client', start);

// Search for a specified string.
function search() {
	var q = $('#titulo-video').val().concat(" ").concat($('#termino_busqueda').val());
	var request = gapi.client.youtube.search.list({
		q: q,
		part: 'snippet',
		maxResults: 50
	});
	
	//Función para encontrar el titulo del video e iterar para colocar los videos en la grilla.
	request.execute(function(response) {
		var str = JSON.stringify(response.result);
		var videos_totales =response.result;
		matriz_principal_videos =[];
        matriz_secundaria_videos = [];
        titulo_video = $("#titulo-video").val();
        
		//itera cada uno de los videos totales y almacena los primeros en la matriz principal y los que 
		//sobran en una matriz secundaria que se muestran luego de darle al botón de buscar mas...
		$.each(videos_totales.items, function(i, item) {
			id_video = item.id.videoId;
			if(i<40){
				matriz_principal_videos.push(id_video);
			}else{
				matriz_secundaria_videos.push(id_video);
			}
		});

		//Si es la primera búsqueda realizada, se debe de dejar como esta, 
		//en caso contrario se elimina la busqueda anterior
		if(flag_segunda_busqueda == true){
			eliminarVideos();
		}
		
		//Se carga la primera tanda de videos.
		cargarMatrizPrincipal();
		
		//Si el termino de video no fue buscado con anterioridad entonces se crea el acordion correspondiente
		if(! (titulo_video == titulo_video_anterior)){
			titulo_video_anterior = $("#titulo-video").val();
			crearAcordion();
		}
		
		//Esto borrar, está unicamente para pruebas...
		$('#res').html('<pre>' + str + '</pre>');
	});
}
      
//Carga la matriz principal y la va agregando a la grilla sortable.
function cargarMatrizPrincipal(){
	for(var i=0 ; i<40 ; i++){
		$("#sortable").append('<li class="ui-state-default" id="resul"><iframe id='+matriz_principal_videos[i]+' height="80px" width="230px" type="text/html" src="https://www.youtube.com/embed/'+ matriz_principal_videos[i]+'"></iframe></li>');
		flag_segunda_busqueda = true;
	}	
	$("#sortable").append('<button id="buscar_mas" class="btn btn-dark" onclick="cargarMatrizSecundaria()">Buscar más</button>');
}

//Carga la matriz secundaria y la va agregando a la grilla sortable.
function cargarMatrizSecundaria(){
        for(var i=0 ; i<10 ; i++){
          $("#sortable").append('<li class="ui-state-default" id="resul"><iframe id='+matriz_secundaria_videos[i]+' height="80px" width="230px" type="text/html"  src="https://www.youtube.com/embed/'+ matriz_secundaria_videos[i] +'"></iframe></li>');
        }
	$("#buscar_mas").remove();
}

//Crea acordiones, donde va a permitir agregar nuevos videos para almacenar en la db
function crearAcordion(){
	$("#acordion").append('<div class="acordiones"><h1 id="tit2">'+$("#titulo-video").val()+'</h1><div><ul class="resultados_grilla2"></ul></div></div>');
    $(".acordiones").accordion();
    $( ".resultados_grilla2").sortable({
		connectWith: "ul"
	});
}

//Carga todos los videos que tenia almacenado el usuario en la BD
function chargeUserVideos(){
	var lista = [];
	var datos;
	$.ajax({
		type: "GET",
		url: "http://localhost/codeigniter/Usuarios/chargeVideos",
		success: function (response) {
			datos = JSON.parse(response);
			$.each(datos, function (i, item) { 
				if(($.inArray(item.titulo_busqueda, lista))==-1){
					lista.push(item.titulo_busqueda);
				}
			});
			$.each(lista, function (i, item) { 
				$("#acordion").append('<div class="acordiones"><h1 id="tit2">'+item+'</h1><div><ul class="resultados_grilla2" id='+item+'></ul></div></div>');
			}); 
			$(".acordiones" ).accordion();
			$( ".resultados_grilla2" ).sortable({
				connectWith: "ul"
			});
                  
			$(".acordiones").each(function () {
				var titulo_video= $(this).find("h1").text();
				$.each(datos, function (i, item) { 
					if(item.titulo_busqueda==titulo_video){                
						$("#"+titulo_video).append('<li class="ui-state-default" id="resul"><iframe id='+item.id_video+' height="80" width="230" type="text/html"  src="https://www.youtube.com/embed/'+item.id_video+'"></iframe></li>');
					}
				});
			});
		}
	});
}

//Elimina todos los videos de la grilla sortable.
function eliminarVideos(){
	$(".resultados_grilla").empty();
}

/*Cuando se agrega un nuevo video al acordeon del usuario, se procede a almacenar en la BD*/
function insertarNuevoVideo(){
	var arreglo1 =[]; 
	var arreglo2 = [];
	$(".acordiones").each(function(i){
		var titulo_busqueda = $(this).find("h1").text();
		var email = $("#emailIUsuario").val();
		arreglo2.push({email: email,titulo_busqueda: titulo_busqueda});
	$(this).find("iframe").each(function(){
		arreglo1.push({email: email,titulo_busqueda: titulo_busqueda, id_video: $(this).attr("id")});
	});
	}); 
	$.ajax({
		type: "POST",
		url: "http://localhost/codeigniter/Usuarios/insertVideos",
		data: {arreglo1: arreglo1, arreglo2: arreglo2},
		success: function () {
		}
	});
}